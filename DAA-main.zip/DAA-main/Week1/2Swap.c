//Swap 2 numbers 

#include <stdio.h>

int main (){


int a = 5;
int b = 10;
int c;

c = a;   
a = b;   
b = c;  

printf("a = %d " , a);
printf("b = %d ", b);

    return 0;
}